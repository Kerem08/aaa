﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace code_first
{
    public class Context:DbContext
    {
        public DbSet<Urun> Uruns { get; set; }
        public DbSet<Calisan> calisans { get; set; }
        public DbSet<Kategori> kategoris { get; set; }

    }
}
