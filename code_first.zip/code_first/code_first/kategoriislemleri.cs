﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace code_first
{
    public class kategoriislemleri
    {
        Context context = new Context();
        public void kategoriekle(Kategori k)
        {
            context.kategoris.Add(k);
            context.SaveChanges();
        }
        public List<Kategori> kategorilistele()
        {
            return context.kategoris.ToList();
        }
        public void kategorisil(int id)
        {
            var silkategori = context.kategoris.First(km => km.KategoriID == id);
            context.kategoris.Remove(silkategori);
            context.SaveChanges();
        }
        public void kategoriguncelle(Kategori k)
        {
            var guncelle = context.kategoris.First(km => km.KategoriID == k.KategoriID);
            guncelle.Kategori_adi = k.Kategori_adi;
            context.SaveChanges();
        }
        public List<Kategori> kategoriara(int id)
        {
            return context.kategoris.Where(km => km.KategoriID == id).ToList();
        }
    }
}
