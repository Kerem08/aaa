﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace code_first
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Context context=new Context(); 
        Urun urun = new Urun();
        Kategori Kategori = new Kategori();
        Calisan Calisan = new Calisan();
        calisanislemleri calisanislemleri =new calisanislemleri();
        Urunislemleri urunislemleri = new Urunislemleri();
        kategoriislemleri kategoriislemleri = new kategoriislemleri();
        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = urunislemleri.urunlistele();
            dataGridView2.DataSource = kategoriislemleri.kategorilistele();
            dataGridView3.DataSource = calisanislemleri.calisanlistele();
            //context.Database.Create();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            urun.Urun_adi=textBox2.Text;
            urun.Urun_markasi=textBox3.Text;
            urun.Urun_fiyati=decimal.Parse(textBox4.Text);
            urun.Urun_adeti=int.Parse(textBox5.Text);
            urunislemleri.urunekle(urun);
            dataGridView1.DataSource = urunislemleri.urunlistele();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            urunislemleri.urunsil(int.Parse(textBox1.Text));
            dataGridView1.DataSource = urunislemleri.urunlistele();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            urun.Urun_adi = textBox2.Text;
            urun.UrunID = int.Parse(textBox1.Text);
            urun.Urun_markasi = textBox3.Text;
            urun.Urun_fiyati = decimal.Parse(textBox4.Text);
            urun.Urun_adeti = int.Parse(textBox5.Text);
            urunislemleri.urunguncelle(urun);
            dataGridView1.DataSource = urunislemleri.urunlistele();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = urunislemleri.urunara(int.Parse(textBox1.Text));
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Kategori.Kategori_adi = textBox6.Text;
            kategoriislemleri.kategoriekle(Kategori);
            dataGridView2.DataSource = kategoriislemleri.kategorilistele();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Calisan.Tc = textBox12.Text;
            Calisan.Ad = textBox11.Text;
            Calisan.Soyad = textBox10.Text;
            Calisan.Departman=textBox9.Text;
            Calisan.maas = int.Parse(textBox8.Text);
            calisanislemleri.calisanekle(Calisan);
            dataGridView3.DataSource = calisanislemleri.calisanlistele();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            calisanislemleri.calisansil(textBox12.Text);
            dataGridView3.DataSource = calisanislemleri.calisanlistele();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Calisan.Tc = textBox12.Text;
            Calisan.Ad = textBox11.Text;
            Calisan.Soyad = textBox10.Text;
            Calisan.Departman = textBox9.Text;
            Calisan.maas = int.Parse(textBox8.Text);
            calisanislemleri.calisanguncelle(Calisan);
            dataGridView3.DataSource = calisanislemleri.calisanlistele();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            dataGridView3.DataSource = calisanislemleri.calisanlariara(textBox12.Text);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            kategoriislemleri.kategorisil(int.Parse(textBox7.Text));
            dataGridView2.DataSource = kategoriislemleri.kategorilistele();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            dataGridView2.DataSource = kategoriislemleri.kategoriara(int.Parse(textBox7.Text));
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Kategori.KategoriID = int.Parse(textBox7.Text);
            Kategori.Kategori_adi = textBox6.Text;
            kategoriislemleri.kategoriguncelle(Kategori);
            dataGridView2.DataSource = kategoriislemleri.kategorilistele();
        }
    }
}
