﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace code_first
{
    public class Urunislemleri
    {
        Context context=new Context();
        public void urunekle(Urun u)
        {
            context.Uruns.Add(u);
            context.SaveChanges();
        }
        public List<Urun> urunlistele()
        {
            return context.Uruns.ToList();
        }
        public void urunsil(int id)
        {
            var silurun = context.Uruns.First(km=>km.UrunID==id);
            context.Uruns.Remove(silurun);
            context.SaveChanges();
        }
        public void urunguncelle(Urun u)
        {
            var guncelle = context.Uruns.First(km => km.UrunID == u.UrunID);
            guncelle.Urun_adi = u.Urun_adi;
            guncelle.Urun_markasi = u.Urun_markasi;
            guncelle.Urun_fiyati = u.Urun_fiyati;
            guncelle.Urun_adeti = u.Urun_adeti;
            context.SaveChanges();
        }
        public List<Urun> urunara(int id)
        {
            return context.Uruns.Where(km => km.UrunID == id).ToList();
        }

    }
}
