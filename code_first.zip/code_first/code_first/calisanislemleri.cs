﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace code_first
{
    public class calisanislemleri
    {
        Context context = new Context();
        public void calisanekle(Calisan c)
        {
            context.calisans.Add(c);
            context.SaveChanges();
        }
        public List<Calisan> calisanlistele()
        {
            return context.calisans.ToList();
        }
        public void calisansil(string tc)
        {
            var silcalisan = context.calisans.First(km => km.Tc == tc);
            context.calisans.Remove(silcalisan);
            context.SaveChanges();
        }
        public void calisanguncelle(Calisan c)
        {
            var guncelle = context.calisans.First(km => km.Tc == c.Tc);
            guncelle.Ad = c.Ad;
            guncelle.Soyad = c.Soyad;
            guncelle.Departman = c.Departman;
            guncelle.maas = c.maas;
            context.SaveChanges();
        }
        public List<Calisan> calisanlariara(string tc)
        {
            return context.calisans.Where(km => km.Tc == tc).ToList();
        }
    }
}
