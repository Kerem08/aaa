﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace code_first
{
    public class Urun
    {
        [Key]
        public int UrunID { get; set; }
        public string Urun_adi { get; set; }
        public string Urun_markasi { get; set; }
        public decimal Urun_fiyati { get; set; }
        public int Urun_adeti { get; set; }
    }
}
